const Logo = () => {
  return <h1>Logo component</h1>;
};

export default Logo;
