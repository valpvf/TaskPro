import Welcome from 'components/Welcome/Welcome';

const WelcomePage = () => {
  return <Welcome />;
};

export default WelcomePage;
